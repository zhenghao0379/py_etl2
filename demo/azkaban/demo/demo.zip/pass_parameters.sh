## 负责接收azkaban web 参数, 放在 commend: python3 test.py ${py_val}

# ('-S', '--START', help='起始日期，默认为昨天')
# ('-E', '--END', help='终止日期，默认为昨天')
# ('-D', '--DAYS', help='运行日期，默认为昨天')
# ('-T', '--RPT_TYPES', help='循环周期类型')
# ('-M', '--MAIL', help='邮件接收者')


echo "------输入参数------"
echo "DAYS:$DAYS"
echo "START:$START"
echo "END:$END"
echo "RPT_TYPE:$RPT_TYPE"
echo "MAIL:$MAIL"
echo "-------------------"

